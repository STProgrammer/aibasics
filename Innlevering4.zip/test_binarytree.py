import unittest
from BinaryTree import BinaryTree
from BinaryTreeNode import BinaryTreeNode
from collections import namedtuple

'''
BinaryTree klassen fungerer ikke så godt med named tuples.
Den er kanskje bare god for String verdier.
'''

class BinaryTreeTest(unittest.TestCase):
    def setUp(self):
        self.person = namedtuple('person', ['lastname', 'firstname', 'address',
                                            'postal_code', 'city'])
        persons_file1 = open('Personer-kort.dta', 'r')
        content = persons_file1.read()
        self.content1 = content.splitlines()
        self.size1 = len(self.content1)
        self.binarytree1 = BinaryTree()
        for p in self.content1:
            self.binarytree1.insert(value = self.person(*p.split(';')))
        persons_file1.close()
        #unbalanced.dta inneholder et data slik at treet er veldig dypt med mindre noder
        persons_file2 = open('unbalanced.dta', 'r')
        content = persons_file2.read()
        self.content2 = content.splitlines()
        self.size2 = len(self.content2)
        self.binarytree2 = BinaryTree()
        for p in self.content2:
            self.binarytree2.insert(value = self.person(*p.split(';')))
        persons_file2.close()
    
        
    def test_findMin(self):
        min_value = self.person('AAKVIK', 'ANETTE', 'BAKLIEN 11', '1360', 'NESBRU')
        node = BinaryTreeNode(min_value)
        self.assertEqual(node, self.binarytree1.findMin())
    
    def test_findMax(self):
        max_value = self.person('ØYFOSS', 'ØISTEIN', 'ORHEIM 76', '0367', 'OSLO')
        node = BinaryTreeNode(max_value)
        self.assertEqual(node, self.binarytree1.findMax())
    
    def test_find(self):
        for p in self.content1:
            person = self.person(*p.split(';'))
            node = BinaryTreeNode(person)
            self.assertEqual(node, self.binarytree1.find(person))
        for p in self.content2:
            person = self.person(*p.split(';'))
            node = BinaryTreeNode(person)
            self.assertEqual(node, self.binarytree2.find(person))
    
    def test_find_key_not_found(self):
        for p in self.content1:
            person = self.person(*p.split(';'))
            with self.assertRaises(KeyError):
                self.binarytree1.find(person)
        for p in self.content2:
            person = self.person(*p.split(';'))
            with self.assertRaises(KeyError):
                self.binarytree2.find(person)
    
    def test_find_in_empty_tree(self):
        tree = BinaryTree()
        value = self.person('SKARSHAUG','ASBJØRN HARALD', 'ALAPMO 72', '7290', 'STØREN')
        self.assertEqual(None, tree.find(value))

    def test_deleteMin(self):
        contents = sorted(self.content1)
        for p in contents:
            person = self.person(*p.split(';'))
            node = BinaryTreeNode(person)
            self.assertEqual(node, self.binarytree1.deleteMin())
        contents = sorted(self.content2)
        for p in contents:
            person = self.person(*p.split(';'))
            node = BinaryTreeNode(person)
            self.assertEqual(node, self.binarytree2.deleteMin())

    def test_deleteMin_root(self):
        btree = BinaryTree()
        min_value = self.person('AAKVIK', 'ANNE-MARIT', 'RISØYVEGEN 17', '1705', 'SARPSBORG')
        btree.insert(value = min_value)
        btree.insert(value = self.person('Zero', 'Zero', 'Zero street', '1234', 'ZeroCity'))
        btree.insert(value = self.person('AAAAAA', 'AAAAA', 'AA street', '1234', 'AACity'))
        btree.deleteMin()
        btree.deleteMin()
        self.assertEqual(None, btree.find(min_value))
    
    def test_deleteMax(self):
        contents = reversed(sorted(self.content1))
        for p in contents:
            person = self.person(*p.split(';'))
            node = BinaryTreeNode(person)
            self.assertEqual(node, self.binarytree1.deleteMax())
        contents = reversed(sorted(self.content2))
        for p in contents:
            person = self.person(*p.split(';'))
            node = BinaryTreeNode(person)
            self.assertEqual(node, self.binarytree2.deleteMax())
            
    
    def test_deleteMax_root(self):
        btree = BinaryTree()
        value1 = self.person('Zero', 'Zero', 'Zero street', '1234', 'ZeroCity')
        value2 = self.person('AAKVIK', 'ANNE-MARIT', 'RISØYVEGEN 17', '1705', 'SARPSBORG')
        value3 = self.person('AAAAAA', 'AAAAA', 'AA street', '1234', 'AACity')
        btree.insert(value = value2)
        btree.insert(value = value1)
        btree.insert(value = value3)
        btree.deleteMax();
        self.assertEqual(None, btree.find(value3))


    def test_delete(self):
        '''
        test_cases = [
           'HUSBY;DAG HELGE;VALDE 32;4353;KLEPP STASJON',
           'AAKVIK;ANNE-MARIT;RISØYVEGEN 17;1705;SARPSBORG',
           'FLATEBØ;PREBEN;EIKETUN 39;9170;LONGYEARBYEN',
           'KRISTIANSEN;MORTEN KRISTIAN;LEINAHYTTA 36;7224;MELHUS',
           'ØYFOSS;WERNER STENVOLD;KIRKVOLL 28;5935;LAVIK',
        ]
        '''
        test_cases = self.content1
        for p in test_cases:
            value = self.person(*p.split(';'))
            node = BinaryTreeNode(value)
            with self.subTest():
                self.assertEqual(node, self.binarytree1.delete(value))
                #This loop is to test if all other values still exists after delete
                treesize = 0
                for p in self.content1:
                    person = self.person(*p.split(';'))
                    if None != self.binarytree1.find(person):
                        treesize += 1
                self.assertEqual(treesize , self.size1 - 1)
        
    
    def test_delete_unbalanced(self):
        '''
        test_cases = [
           'MANJOSSOV;UNNI MERETHE;BURSTUEN 85;3535;KRØDEREN',
           'MARHAUG;VIDAR;ØDELI 69;2688;LOM',
           'MANNVIK;TRULS MAGNE;RENDALEN 112;4974;SØNDELED',
           'MARTNES;PER KÅRE;ONSTAD NORDRE 1;5001;BERGEN',
           'MANJOSSOV;UNNI MERETHE;BURSTUEN 85;3535;KRØDEREN',       
        ]
        '''
        test_cases = self.content2
        for p in test_cases:
            value = self.person(*p.split(';'))
            node = BinaryTreeNode(value)
            with self.subTest():
                self.assertEqual(node, self.binarytree2.delete(value))
                #This loop is to test if all other values still exists after delete
                treesize = 0
                for p in self.content2:
                    person = self.person(*p.split(';'))
                    if None != self.binarytree2.find(person):
                        treesize += 1
                self.assertEqual(treesize , self.size2 - 1)
    
    def test_delete_left_tree(self):
        btree = BinaryTree()
        value1 = self.person('AAKVIK', 'ANNE-MARIT', 'RISØYVEGEN 17', '1705', 'SARPSBORG')
        value2 = self.person('AAJVIK', 'ANNE-MARIT', 'RISØYVEGEN 17', '1705', 'SARPSBORG')
        value3 = self.person('AAIVIK', 'ANNE-MARIT', 'RISØYVEGEN 17', '1705', 'SARPSBORG')
        btree.insert(value=value1); btree.insert(value=value2); btree.insert(value=value3)
        node = BinaryTreeNode(value1)
        self.assertEqual(node, btree.delete(value1))
        node = BinaryTreeNode(value2)
        self.assertEqual(node, btree.find(value2))
        node = BinaryTreeNode(value3)
        self.assertEqual(node, btree.find(value3))
        
    def test_delete_single_value(self):
        btree = BinaryTree()
        value1 = self.person('AAKVIK', 'ANNE-MARIT', 'RISØYVEGEN 17', '1705', 'SARPSBORG')
        btree.insert(value = value1);
        btree.delete(value1)
        node = BinaryTreeNode(value1)
        self.assertNotEqual(node, btree.find(value1))

    def test_insert_value(self):
        btree1 = BinaryTree()
        for p in self.content1:
            person = self.person(*p.split(';'))
            node = BinaryTreeNode(person)
            self.assertEqual(node, btree1.insert(value = person))
        btree2 = BinaryTree()
        for p in self.content2:
            person = self.person(*p.split(';'))
            node = BinaryTreeNode(person)
            self.assertEqual(node, btree2.insert(value = person))
    
    def test_insert_node(self):
        value1 = self.person('WIKILUND','JOHAN', 'SVETUN 11', '8510', 'NARVIK')
        node1 = BinaryTreeNode(value1)
        value2 = self.person('ALFRED', 'POLLEN', 'gate 11', '1234', 'KONGSBERG')
        node2 = BinaryTreeNode(value2)
        self.assertEqual(node1, self.binarytree2.insert(treenode=node1))
        self.assertEqual(node2, self.binarytree2.insert(treenode=node2))
        for p in self.content2:
            person = self.person(*p.split(';'))
            node = BinaryTreeNode(person)
            self.assertEqual(node, self.binarytree2.find(person))
    
    
    def test_insert_to_empty_tree(self):
        btree = BinaryTree(None)
        person = self.person('WIKILUND','JOHAN', 'SVETUN 11', '8510', 'NARVIK')
        node = BinaryTreeNode(person)
        self.assertEqual(node, btree.insert(value=person))
        
    def test_insert_node_to_empty_tree(self):
        btree = BinaryTree(None)
        person = self.person('WIKILUND','JOHAN', 'SVETUN 11', '8510', 'NARVIK')
        node = BinaryTreeNode(person)
        self.assertEqual(node, btree.insert(treenode=node))


    def test_insert_duplicate(self):
        person = self.person('AAKVIK', 'ANNE-MARIT', 'RISØYVEGEN 17', '1705', 'SARPSBORG')
        with self.assertRaisesRegex(Exception, "Duplicate key"):
            self.binarytree1.insert(value = person)
        
    
    def test_insert_None_value(self):
        with self.assertRaisesRegex(Exception, "Attempt to insert an empty space into Binary Tree"):
            self.binarytree1.insert(value = None)


    def test_insert_empty_node(self):
        node = BinaryTreeNode(None)
        with self.assertRaisesRegex(Exception, "Attempt to insert an Node into Binary Tree with no key value"):
            self.binarytree1._getnodes(treenode = node)

        


if __name__ == '__main__':
    import sys;sys.argv = ['', 'BinaryTreeTest']
    unittest.main()